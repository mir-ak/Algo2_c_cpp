#ifndef RAND_H
#define RAND_H

class Rand
{
public:
    int randNum(int x,int y);
    Rand();
};

#endif
