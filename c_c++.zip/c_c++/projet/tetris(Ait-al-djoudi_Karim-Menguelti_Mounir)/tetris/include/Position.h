#ifndef POSITION_H_
#define POSITION_H_

#include <iostream>
using namespace std;

class Position{
public:
	void save_position();		
	void place_cordonnee(const int x,const int y); 
	void res_position();   
};
#endif
